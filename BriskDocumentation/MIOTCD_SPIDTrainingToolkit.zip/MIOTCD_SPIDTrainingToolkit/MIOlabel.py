import numpy as np
import pandas as pd
from PIL import Image
import shutil
import os

##################################################################################################################################################################################

#classes = ["articulated_truck", "bicycle", "bus", "car","motorcycle", "motorized_vehicle", "non-motorized_vehicle", "pedestrian", "pickup_truck", "single_unit_truck", "work_van"]
classes = ["truck", "bicycle", "bus", "car","motorcycle", "motorized_vehicle", "non-motorized_vehicle", "pedestrian"]

gtrain = pd.read_csv('gt_train.csv')
trainingImageRoot='/usr/local/data/vmrl/liqiang/Topview/Localization_MIOTCD/MIO-TCD-Localization/train'
totalrows=len(gtrain)
totalcolumns=len(gtrain.columns)

##################################################################################################################################################################################
def convert(size, box):
    dw = 1./size[0]
    dh = 1./size[1]
    x = (box[0] + box[1])/2.0
    y = (box[2] + box[3])/2.0
    w = box[1] - box[0]
    h = box[3] - box[2]
    x = x*dw
    w = w*dw
    y = y*dh
    h = h*dh
    return (x,y,w,h)

    
def convert_annotation(imageFile, index):
    
    
    filename='labels/'+str(gtrain.iloc[index,0]).zfill(8)+'.txt'
    out_file=open(filename, 'a')
    
    img=Image.open('train/'+imageFile)
    [imageH, imageW, imageC]=np.shape(img)
    cls=gtrain.iloc[index,1]

    if (cls=="single_unit_truck" or cls=="articulated_truck"):
        clsIndex=0 ## ->truck
    elif (cls=="pickup_truck" or cls=="work_van"):
        clsIndex=3
    else:
        clsIndex=classes.index(cls)
    
    b=(float(gtrain.iloc[index,2]), float(gtrain.iloc[index,4]), float(gtrain.iloc[index,3]), float(gtrain.iloc[index,5]))
    bb=convert((imageW, imageH), b)

    
    outrow=str(clsIndex)+ " "+ " ".join([str(a) for a in bb])+'\n'
    
    out_file.write(outrow)
    out_file.close()
    return

##################################################################################################################################################################################


if os.path.exists('labels'):
    shutil.rmtree('labels')
os.makedirs('labels')
    
    
if os.path.exists('train.txt'):
    os.remove('train.txt')
list_file=open('train.txt', 'a')

currentframe=-1
for objectindex in range(0, totalrows):
    
    frame=gtrain.iloc[objectindex,0]
    imageFile=str(frame).zfill(8)+'.jpg'
    convert_annotation(imageFile, objectindex)
    
    if(frame!=currentframe):
        list_file.write(trainingImageRoot+'/'+imageFile+'\n')
        currentframe=frame
        print (objectindex, frame, currentframe)
    
    

print (currentframe)
list_file.close()
        
        



    
    
    
    
    






